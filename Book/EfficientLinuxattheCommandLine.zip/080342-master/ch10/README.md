This directory contains examples from chapter 10
of [*Efficient Linux at the Command Line*](https://efficientlinux.com/) by [Daniel J. Barrett](https://danieljbarrett.com).
