This directory contains examples from chapter 5
of [*Efficient Linux at the Command Line*](https://efficientlinux.com/) by [Daniel J. Barrett](https://danieljbarrett.com).
