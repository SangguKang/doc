print("This is a Python file")
