These files are the examples from
[*Efficient Linux at the Command Line*](https://efficientlinux.com/)
by [Daniel J. Barrett](https://danieljbarrett.com/). With these files on your Linux computer,
you'll can easily run the book's sample commands exactly as
written. Just `cd` to the appropriate directory and run the
commands. The example files are organized by chapter and section.

For example, before running the sample commands in chapter 2, run `cd
ch02`. Then look for a subdirectory whose purpose matches the section
of the book you're reading. The files for the section "Pattern
Matching for Filenames" are in the subdirectory
`pattern_matching_for_filenames`, and so on.

Have fun!

