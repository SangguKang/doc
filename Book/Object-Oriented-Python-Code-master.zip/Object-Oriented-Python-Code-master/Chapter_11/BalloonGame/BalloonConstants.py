# Constants used by more than one Python modules

N_BALLOONS = 15  # number of balloons in a round of the game
BALLOON_MISSED = 'Missed'  # balloon went off the top
BALLOON_MOVING = 'Balloon Moving'  # balloon is moving
